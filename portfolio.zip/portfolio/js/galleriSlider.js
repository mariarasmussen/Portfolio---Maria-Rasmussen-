
/* Denne kode gør at der kommer bevægelse i første billede*/
let bg = document.getElementById("bg");
let moon = document.getElementById("kugle");
let mountain = document.getElementById("glitter");
let road = document.getElementById("hånd");
let tekst = document.getElementById("fest_tekst");

window.addEventListener('scroll', function () {
    var value = window.scrollY;

    bg.style.top = value * 0.5 + 'px';
    kugle.style.left = -value * 0.5 + 'px';
    glitter.style.top = -value * 0.15 + 'px';
    hånd.style.top = value * 0.15 + 'px';
    fest_tekst.style.top = value * 1 + 'px';
})