
/* Denne kode gør at der kommer bevægelse i første billede*/
let bg = document.getElementById("bg");
let moon = document.getElementById("kugle");
let mountain = document.getElementById("glitter");
let skygge = document.getElementById("skygge");
let tekst = document.getElementById("logo");

window.addEventListener('scroll', function () {
    var value = window.scrollY;

    bg.style.top = value * 0.5 + 'px';
    kugle.style.left = -value * 0.5 + 'px';
    glitter.style.top = -value * 0.15 + 'px';
    skygge.style.top = value * 0.15 + 'px';
    logo.style.top = value * 1 + 'px';
})


window.onscroll = function () { myFunction() };

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
    if (window.pageYOffset > sticky) {
        header.classList.add("sticky");
    } else {
        header.classList.remove("sticky");
    }
}